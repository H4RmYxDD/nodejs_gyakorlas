const express = require('express');
const path = require('path');
const app = express();

app.get('/index', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.listen(3001, () => {
  console.log('Szerver fut a 3001-es porton.');
});
